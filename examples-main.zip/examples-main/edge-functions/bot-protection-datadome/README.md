---
marketplace: false
---

# Bot Protection with DataDome

This example has been moved to [`edge-middleware`](/edge-middleware/bot-protection-datadome).

