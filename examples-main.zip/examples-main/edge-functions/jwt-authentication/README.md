---
marketplace: false
---

# JWT Authentication

This example has been moved to [`edge-middleware`](/edge-middleware/jwt-authentication).
