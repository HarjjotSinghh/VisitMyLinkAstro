---
marketplace: false
---

# Power Parity Pricing

This example has been moved to [`edge-middleware`](/edge-middleware/power-parity-pricing).

