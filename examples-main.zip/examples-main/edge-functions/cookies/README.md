---
marketplace: false
---

# Cookies Example

This example has been moved to [`edge-middleware`](/edge-middleware/cookies).
