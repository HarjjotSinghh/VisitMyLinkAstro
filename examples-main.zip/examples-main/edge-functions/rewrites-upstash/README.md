---
marketplace: false
---

# Rewrites with Upstash

This example has been moved to [`edge-middleware`](/edge-middleware/rewrites-upstash).
