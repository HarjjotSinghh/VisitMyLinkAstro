---
marketplace: false
---

# Geolocation

This example has been moved to [`edge-middleware`](/edge-middleware/geolocation).
