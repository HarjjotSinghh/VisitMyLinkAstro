---
marketplace: false
---

# Feature Flags with Optimizely

This example has been moved to [`edge-middleware`](/edge-middleware/feature-flag-optimizely).
