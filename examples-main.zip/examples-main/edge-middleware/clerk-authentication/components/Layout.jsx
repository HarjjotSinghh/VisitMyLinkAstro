export const Layout = ({ children }) => {
  return <div>{children}</div>
}
