export const UID_COOKIE = 'uid'
// This is the experiment that will be used to determine the bucket
export const EXPERIMENT = 'statsig_example'
// Default Experiment Group Fallback
export const GROUP_PARAM_FALLBACK = 'error_default_bucket'
