export const COOKIE_NAME = 'ab-optimize'
